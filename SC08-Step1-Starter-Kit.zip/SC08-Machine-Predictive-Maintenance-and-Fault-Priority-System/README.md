# SC08 — Machine Predictive Maintenance and Fault Priority System

## Project goal
Given machine sensor readings, estimate fault risk and maintenance priority so that a maintenance engineer can decide which machine needs attention first.

## Step 1 scope
Step 1 prepares the project for the M1 Soft Computing method. It does **not** implement the ANN/Fuzzy model yet.

Step 1 delivers:
- project contract
- data dictionary
- small starter fixture
- five mandatory test cases
- simple threshold baseline
- data validation program
- Product V1 screen sketch
- Git evidence

## Expected outputs
- `fault_probability` — 0 to 1 (M1 output; not produced by the Step 1 baseline yet)
- `risk_band` — `low`, `medium`, `high`
- `maintenance_priority` — `routine`, `soon`, `immediate`

## Repository structure

```text
docs/
  STEP-1.md
  baseline-pseudocode.md
  product-v1-sketch.png
data/
  README.md
  sample_input.csv
  invalid_input.csv
src/
  validate_data.py
notebooks/
app/
results/
report/
README.md
requirements.txt
```

## Step 1 run

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python src/validate_data.py
```

The validator checks the valid fixture and then deliberately checks the invalid fixture. It should print a PASS for the valid fixture and an expected FAIL message for the invalid fixture.

## Dataset/source note

The project uses the published rotating-machine condition-monitoring dataset described by Jung et al. (2023), which contains vibration, temperature, motor-current and operating-condition data under varying load/speed conditions. The paper identifies the Mendeley Data repository and documents the experimental setup and operating conditions.

Source:
https://pmc.ncbi.nlm.nih.gov/articles/PMC10036499/

Data repository:
https://data.mendeley.com/datasets/ztmf3m7h5x

The Step 1 CSV is a small project fixture, not a claim that these 20 rows are raw records from the source dataset. The final dataset/scenario pipeline must document the exact extraction/transformation procedure before M1.

## Important assumptions
- `load_pct` is a project-level normalized representation of operating load. The source dataset reports load conditions in Nm for the load-condition experiment; the project converts the selected operating-load levels to a 0–100% scale for the dashboard.
- Temporary baseline thresholds are explicitly marked as temporary and must be replaced/validated after the team fixes the final dataset and operating range.
- Missing sensor values are treated as a validation/handling case rather than silently imputed in Step 1.
