# Step 1 Project Contract

## Team and responsibilities
- Shivansh Kumar — Repository / integration (replace if needed)
- Member 2 — Data
- Member 3 — Baseline
- Member 4 — Testing / UI

> Replace Member 2–4 with the actual names before submission.

## One-sentence problem
Given machine sensor readings, estimate fault risk and maintenance priority.

## User of the product
A maintenance engineer deciding which machine needs attention first.

## Inputs and units

| Field | Meaning | Type / unit | Starter rule |
|---|---|---|---|
| `reading_id` | Unique sensor row identifier | text | unique, non-empty |
| `vibration` | Machine vibration level | mm/s RMS* | non-negative |
| `temperature_c` | Machine temperature | °C* | project fixture range documented in data/README.md |
| `rpm` | Rotational speed | revolutions/min | 0 or more |
| `load_pct` | Normalized machine operating load | % | 0 to 100 |
| `severity` | Observed severity for the fixture/test case | numeric category 0–3 | 0, 1, 2, or 3 |
| `fault_label` | Known result used for testing | category | `no_fault`, `fault`, or `unknown` |

\* Confirm exact units and measurement definition against the final selected source files before using the data for M1. The source paper describes vibration and temperature measurements but the final project dataset must preserve the source's documented units.

## Outputs and units
- `fault_probability` — 0 to 1
- `risk_band` — `low`, `medium`, `high`
- `maintenance_priority` — `routine`, `soon`, `immediate`

## Baseline method
Use temporary sensor-threshold rules. Count the number of crossed thresholds:
- 0 crossed thresholds → low risk
- 1 crossed threshold → medium risk
- 2 or more → high risk

Map:
- low → routine
- medium → soon
- high → immediate

The exact thresholds in the fixture are temporary and must be revalidated against the final dataset.

## Soft Computing method for M1
An ANN fault-risk model **or** a fuzzy priority controller, compared with the crisp sensor-threshold baseline.

## Advanced method for M2
Combine ANN risk with fuzzy severity, test noisy and extreme readings, and deploy the dashboard.

## Dataset/scenario source
Primary public source:
Jung et al. (2023), *Vibration, acoustic, temperature, and motor current dataset of rotating machine under varying operating conditions for fault diagnosis*.

Paper:
https://pmc.ncbi.nlm.nih.gov/articles/PMC10036499/

Mendeley Data:
https://data.mendeley.com/datasets/ztmf3m7h5x

The source includes vibration, temperature, motor current, varying-load experiments, and varying-speed experiments. The Step 1 fixture is a small scenario/validation fixture derived from the project schema; it is not presented as a raw download.

## Five mandatory test cases

| Case | Expected behavior |
|---|---|
| MCH-001 | Normal operation → low/routine |
| MCH-002 | High vibration only → medium/soon |
| MCH-003 | High temperature + high load → high/immediate |
| MCH-004 | Several extreme signals → high/immediate |
| MCH-005 | Missing vibration → validation/handling warning; do not silently invent a sensor value |

## Product V1 screen sketch
See `docs/product-v1-sketch.png`.

## Risks and assumptions
1. The Step 1 fixture is intentionally small and must not be described as the final training dataset.
2. Temporary thresholds are not clinical/safety limits; they are only a baseline for comparison.
3. The final dataset must record the exact source, licence, machine type, sampling frequency, units, label meaning, and class balance.
4. Missing sensor readings must be handled explicitly.
5. The project should not claim real-world deployment performance before validation on the final dataset.

## Step 1 completion evidence
- Repository URL: __________________________
- Validation PASS screenshot: `results/step1/`
- Expected FAIL screenshot: `results/step1/`
- Git history: repository commit history
- Product V1 sketch: `docs/product-v1-sketch.png`
