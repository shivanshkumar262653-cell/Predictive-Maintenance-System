# Baseline Pseudocode

```text
READ one input row

IF required fields are structurally invalid:
    SHOW a clear validation error
ELSE:
    warning_count = 0

    IF vibration > TEMP_VIBRATION_THRESHOLD:
        warning_count = warning_count + 1

    IF temperature_c > TEMP_TEMPERATURE_THRESHOLD:
        warning_count = warning_count + 1

    IF rpm > TEMP_RPM_THRESHOLD:
        warning_count = warning_count + 1

    IF load_pct > TEMP_LOAD_THRESHOLD:
        warning_count = warning_count + 1

    IF warning_count == 0:
        risk_band = "low"
        maintenance_priority = "routine"
    ELSE IF warning_count == 1:
        risk_band = "medium"
        maintenance_priority = "soon"
    ELSE:
        risk_band = "high"
        maintenance_priority = "immediate"

    PRINT risk_band
    PRINT maintenance_priority
    PRINT which rules were crossed
    SAVE result for later comparison
```

## Temporary Step 1 thresholds

These are fixture thresholds only. They are **not** claimed to be source-dataset limits.

- vibration > 5.0 mm/s → warning
- temperature_c > 60 °C → warning
- rpm > 3200 rpm → warning
- load_pct > 90% → warning

Before M1 training, replace or justify these thresholds using the final documented dataset and operating range.
