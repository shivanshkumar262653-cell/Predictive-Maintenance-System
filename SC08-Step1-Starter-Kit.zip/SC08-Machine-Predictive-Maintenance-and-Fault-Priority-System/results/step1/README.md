# Step 1 evidence

Save here:
1. Screenshot of `python src/validate_data.py` showing VALID FIXTURE: PASS.
2. Screenshot showing INVALID FIXTURE: EXPECTED FAIL.
3. Optional faculty-demo screenshots.

Do not fabricate evidence; capture it from an actual run.
