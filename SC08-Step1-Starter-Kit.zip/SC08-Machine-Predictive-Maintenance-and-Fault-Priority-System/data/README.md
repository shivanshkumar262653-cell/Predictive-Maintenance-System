# Data README

## Field meanings

| Field | Meaning | Unit/type | Step 1 rule |
|---|---|---|---|
| reading_id | Unique reading identifier | text | unique |
| vibration | Machine vibration level | mm/s RMS* | >= 0 |
| temperature_c | Machine temperature | °C* | project fixture range 20–90 |
| rpm | Rotational speed | rpm | 0–3600 in fixture |
| load_pct | Normalized operating load | % | 0–100 |
| severity | Fixture severity | 0–3 | integer category |
| fault_label | Known test result | category | no_fault/fault/unknown |

\* Confirm the exact measurement unit/definition against the final source files before M1. The source paper documents vibration and temperature measurements, but Step 1 must not silently claim a unit not verified from the selected source file.

## Source
Jung et al. (2023), *Vibration, acoustic, temperature, and motor current dataset of rotating machine under varying operating conditions for fault diagnosis*.

Paper:
https://pmc.ncbi.nlm.nih.gov/articles/PMC10036499/

Mendeley Data:
https://data.mendeley.com/datasets/ztmf3m7h5x

The source describes experiments under varying load and varying speed, including vibration, temperature and rotational-speed measurements.

## Step 1 fixture policy
`sample_input.csv` contains a small, clearly labeled project fixture for validation and demonstration. It is **not raw source data** and must not be presented as such.

## Missing values
A missing sensor value is handled explicitly as a test case. The validator reports it as a handled validation case rather than silently replacing it.

## Final data plan
After Step 1 approval, create the reproducible 10,000+ record/scenario pipeline and document:
- machine type
- sampling frequency
- units
- label meaning
- class balance
- licence
- extraction/transformation steps
