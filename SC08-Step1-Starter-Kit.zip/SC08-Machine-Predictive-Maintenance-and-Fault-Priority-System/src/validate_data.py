import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
VALID_FILE = BASE / "data" / "sample_input.csv"
INVALID_FILE = BASE / "data" / "invalid_input.csv"

REQUIRED = [
    "reading_id", "vibration", "temperature_c",
    "rpm", "load_pct", "severity", "fault_label"
]
NUMERIC = ["vibration", "temperature_c", "rpm", "load_pct", "severity"]
ALLOWED_LABELS = {"no_fault", "fault", "unknown"}
ALLOWED_SEVERITY = {0, 1, 2, 3}

def validate(path: Path, allow_missing_vibration_case=False):
    df = pd.read_csv(path)
    errors = []

    missing_columns = [c for c in REQUIRED if c not in df.columns]
    if missing_columns:
        errors.append(f"Missing columns: {missing_columns}")
        return df, errors

    if df["reading_id"].duplicated().any():
        errors.append("Duplicate reading_id found.")

    for column in NUMERIC:
        converted = pd.to_numeric(df[column], errors="coerce")
        if column == "vibration" and allow_missing_vibration_case:
            bad = converted.notna() & ~converted.between(0, float("inf"))
        else:
            bad = converted.isna() | ~converted.between(0, float("inf"))
        if bad.any():
            errors.append(f"{column} contains an invalid numeric value.")

    if not df["load_pct"].isna().any() and not df["load_pct"].between(0, 100).all():
        errors.append("load_pct must be between 0 and 100.")

    if not df["severity"].isna().any() and not set(df["severity"].astype(int)).issubset(ALLOWED_SEVERITY):
        errors.append("severity must be one of 0, 1, 2, 3.")

    if not df["fault_label"].astype(str).isin(ALLOWED_LABELS).all():
        errors.append("fault_label contains an undocumented category.")

    missing = df[REQUIRED].isna().sum()
    missing_total = int(missing.sum())
    if missing_total:
        if allow_missing_vibration_case and missing.get("vibration", 0) == 1 and missing_total == 1:
            print("INFO: one missing vibration value is intentionally present for MCH-005 and is handled as a test case.")
        else:
            errors.append(f"Unexpected missing values: {missing.to_dict()}")

    return df, errors

print("=== SC08 STEP 1 VALIDATION ===")
valid_df, valid_errors = validate(VALID_FILE, allow_missing_vibration_case=True)
print("shape:", valid_df.shape)
print("columns:", list(valid_df.columns))

if valid_errors:
    print("VALID FIXTURE: FAIL")
    for error in valid_errors:
        print(" -", error)
    raise SystemExit(1)
else:
    print("VALID FIXTURE: PASS")

print("\n=== EXPECTED INVALID CASE ===")
invalid_df, invalid_errors = validate(INVALID_FILE)
if invalid_errors:
    print("INVALID FIXTURE: EXPECTED FAIL")
    for error in invalid_errors:
        print(" -", error)
else:
    print("INVALID FIXTURE: UNEXPECTED PASS")
    raise SystemExit(1)
